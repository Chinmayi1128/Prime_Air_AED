/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.Organisation;

import Hospital.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author Chinmayi Shaligram
 */
public class Emergency911DepartmentOrganisation extends Organisation {

    public Emergency911DepartmentOrganisation() {
        super(Organisation.Type.EMERGENCY911DEPARTMENT.getValue());
    }

 
    
    
    
}
