/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Employee;

import Person.PersonDirectory;



/**
 *
 * @author Aditya
 */
public class EnterpriseAdmin extends Employee {
    
    private boolean available;

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
    
    
 
    
}
