/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmergencySystem.Enterprise;

/**
 *
 * @author abhisheksatbhai
 */
public class EcomEnterprise extends Enterprise{
            public EcomEnterprise(String name) {
       
        super(name, Enterprise.EnterpriseType.ECOMENTERPRISE);{
         
    }
}
}
